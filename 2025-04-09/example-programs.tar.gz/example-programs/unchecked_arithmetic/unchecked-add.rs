
fn main() {
    let a:i16 = 42;
    let b:i16 = -43;
    
    let _result = unchecked_op(a, b);

}

fn unchecked_op(a: i16, b: i16) -> i16 {
    assert!((a + b < i16::MAX) && (a + b > i16::MIN));
    unsafe { a.unchecked_add(b) }

}
