#![allow(unused)]
#![allow(dead_code)]

fn main() {
    let a = Letter::A;

    let mut x  = WithData::X;
    let y  = WithData::Y { y: 42};
    let z  = WithData::Z { y:42, z: false };
    let zz = WithData::ZZ(42, 43, true);

    match_enums(a, &mut x, y);

    let mut my_struct = MyStruct { a_value: 32, another: false, a_third: 32};
    use_refs(&mut my_struct);
}

enum Letter {
    A = 65,
    B,
    M = 77,
}

#[repr(u16)]
enum WithData {
    X = 88,
    Y{y:i32} = 89,
    Z{y:i16, z: bool} = 90,
    ZZ(i8, i8, bool) = 9090,
}

fn match_enums(a: Letter, x: &mut WithData, y: WithData) {

    if let WithData::Y{y} = x {
        let zzz = WithData::Y{y: *y};
    } else {

        if let Letter::A = a {
            let zzz = a;
        }

        match y {
            WithData::Y{y:_} => 
                *x = y,
            WithData::Z{y:_, z} => 
                *x = WithData::ZZ(0, 0, z),
            _ => ()
        }
    }
}

#[derive(Debug)]
struct MyStruct {
    a_value: i8,
    another: bool,
    a_third: usize,
}

#[derive(Debug)]
struct Enclosing<'a> {
    inner: &'a mut MyStruct
}

fn use_refs(a: &mut MyStruct) {

    // mutate field through ref and double-ref
    let r1 = &mut (a.a_value);
    *r1 = 42;
    assert!(a.a_value == 42);
    let mut r1 = &mut (a.a_value);
    let r2 = &mut r1;
    **r2 = 43;
    assert!(a.a_value == 43);

    // create reference-field chain
    let mut e = Enclosing{inner: a};
    let ee = &mut e;

    // read and  write values through chain of ref/field projections
    let vv = (*(*ee).inner).a_value;
    assert!(vv == 43);

    (*(*ee).inner).another = true;

    let r3 = &mut (*ee).inner.a_third;
    *r3 = (*(*ee).inner).a_value as usize;

    assert!(a.another);
    assert!(a.a_third == 43);

}
